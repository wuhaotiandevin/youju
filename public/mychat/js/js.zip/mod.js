
	var authorization = 1;//0普通用户 1管理员
	//获取房间列表
	function getRoomList(){
		$.ajax({
			url:"https://www.suprass.cn/portal/chat/channel",
			type:"get",	
			dataType:"json",
			success:function(e){
				e = eval(e.data);
				//到前端
				var size = e.data.total_size;
				var cname;
				for(var i = 0;i < size;i ++){
					cname = e.data.channels[i].channel_name
					$("#chatRoomList").append("<div class='chat-room-all-item' id='channel_item_"+ cname + "'><p class='chat-room-name chat-room-part-name' style='display: flex; align-items: center; background: transparent;' alt='hide'><span class='chat-room-name-zhan'><img src='img/sanjiaoicon.png'></span><span style='flex:1; display:flex; flex-direction:column; margin:0 8px; font-style:normal; font-size:14px; text-align:center'><e style='font-size:14px;color: #333;'>" +cname+"</e><e style='font-size:14px; color:#999;'>测试使用</e></span><span class='chat-room-name-count' id='user_size_" +cname + "'>（150）</span></p><div style='display: none;' id='channelroom_"+ cname + "'></div></div>" );
					getChannelUser(cname);
				}
			},
			error:function() {
				console.log("获取房间列表失败");
			}
		})
	};
	//获取频道人数
	function getChannelUser(channel_name){
		$.ajax({
			url:"https://www.suprass.cn/portal/chat/channel_users",
			data:{"cname":channel_name},
			dataType:"json",
			success:function(e){
				e = eval(e.data);
				var size = e.data.audience_total;
				var name;
				$("#user_size_" + channel_name).html("(" + e.data.audience_total + ")");
				for(var i = 0;i < size;i ++){
					name = e.data.audience[i];
					$("#channelroom_" + channel_name).append("<div class='chat-room-users'><div nickname='"+name+"' class='chat-room-item-empty chat-room-item' style='order:1000; display:flex;' account='"+name+"'><span class='chat-room-span-header'><img class='chat-room-img-header' onerror='this.src=&#39;img/noavatar_1.jpg&#39;;' src='img/noavatar_1.jpg'></span><span class='chat-talk-light chat-room-img-online' style='display:none;'></span><div style='display:flex;flex-direction: column;justify-content: flex-start;margin-left:10px;'><div class='chat-room-item-icons'><span style='display:none;'><img class='img-xin-icon' src='img/xinicon.png'></span><span></span></div><span class='chat-room-name' style='display:inline-block;'><font style='color:#666'>"+name+"</font></span></div></div></div>");
				}
				//加载完成绑定点击事件
				$(".chat-room-part-name").on('click',function(){
   					lawn($(this));
   				});
   				//弹出封禁窗口
    			$("#user_mod_setTicket",".chat-room-item-empty", ".chat-room-item").on('click',function(){
			    	// if(authorization == 0)
			    	// 	$(".user_mod_win").hide();
			    	if($(this).attr("uid") == undefined)
			    		var id = $(this).attr("account");
			    	else
			    		var id = $(this).attr("uid");
			    	$("#user_id_cname").html(id);
			    	$(".user_mod_win").show();
    			})
			}
		})
	}
	//踢人操作
	function setTicket(cname,uid,time,that){
		if(authorization == 0){
			that.hide();
			console.log("无权限，被驳回");
			return;
		}
		$.ajax({
			url:"https://www.suprass.cn/portal/chat/create_rule",
			type:"POST",
			dataType:"json",
			data:{"cname":cname,"uid":uid,"time":time},
			success:function(e){
				e = eval(e.data);
				console.log(e);
			},
			error:function(){
				alert("踢人操作不成功，请稍后重试！");
			}
		})
		if(that != undefined)
			that.hide();
	}
	//获取服务端的踢人规则列表。
	function getTicketRules(){
		if(authorization == 0){
			that.hide();
			return;
		}
		$.ajax({
			url:"https://www.suprass.cn/portal/chat/rule",
			type:"get",
			dataType:"json",
			success:function(e){
				e = eval(e.data);
				console.log(e);
			}
		})
	}
	//更新服务端踢人的生效时间
	function updateTicketTime(id,time){
		if(authorization == 0){
			that.hide();
			return;
		}
		$.ajax({
			url:"https://www.suprass.cn/portal/chat/update_rule",
			type:"get",
			dataType:"json",
			data:{"id":id,"time":time},
			success:function(e){
				e = eval(e.data);
				console.log(e);
			}
		})
	}
	//删除服务端踢人规则。
	function deleteTicket(id){
		if(authorization == 0){
			that.hide();
			return;
		}
		$.ajax({
			url:"https://www.suprass.cn/portal/chat/delete_rule",
			type:"get",
			dataType:"json",
			data:{"id":id},
			success:function(e){
				e = eval(e.data);
				console.log(e);
			}
		})
	}
	//获取用户权限
	function getAuthorization(_uid){
		$.get("url",{"uid":_uid},function(e){
			e = eval(e.data);
			authorization = e.authorization;
			return authorization;
		})
	}
	//
	function test(){
		return authorization;
	}
	