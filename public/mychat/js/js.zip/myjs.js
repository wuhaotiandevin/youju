$(function(){
	//礼物栏展开
    $(".chat-center-gift-show").click(function (){  
        var flag = $(".chat-center-gift-content").is(":hidden");  
        if(flag){  
            $(".chat-center-gift-content").show();  
        }else{  
            $(".chat-center-gift-content").hide();  
        }  
    });
    //礼物选项卡切换
    $(".chat-center-gift-tab").on("click", "div", function() {
        var index = $(this).index();
        $(".chat-center-gift-list .gifttab").addClass("hide");
        var showTab = $(".chat-center-gift-list .gifttab").eq(index);
        showTab.removeClass("hide");
        $(".chat-center-gift-tab > div").removeClass("gift-selected");
        $(this).addClass("gift-selected");
        if (showTab.find(".current").length == 0) {
            showTab.find(".chat-center-gift-item").eq(0).addClass("current")
        }
    });
    //礼物选择
    $(".chat-center-gift-list").on("click", ".chat-center-gift-item", function() {
        var parent = $(this).parent();
        parent.find(".chat-center-gift-item").removeClass("current");
        $(this).addClass("current")
    });
    //礼物数量选择
    $("#spanShowGiftCount").on("click", function(e) {
        e.stopPropagation();
        if ($("#giftCountList").css("display") == "none") {
            $("#giftCountList").show();
            $(".gift-send-teacher-list").hide()
        } else {
            $("#giftCountList").hide()
        }
    });
    //点击礼物数量
    $("#giftCountList").on("click", "span", function(e) {
        e.stopPropagation();
        var val = $(this).text();
        $("#giftCountList span").removeClass("current");
        $(this).addClass("current");
        $("#inputGiftCount").val(val)
    });
    //弹出发送礼物对象
    $("#selectGiftTeacher, #spanTeacherShow").on("click", function(e) {
        e.stopPropagation();
        if ($(".gift-send-teacher-list").css("display") == "none") {
            $(".gift-send-teacher-list").show();
            $("#giftCountList").hide()
        } else {
            $(".gift-send-teacher-list").hide()
        }
    });
    //选择发送礼物对象
     $("#divTeacherList").on("click", "p", function() {
        var uid = $(this).attr("uid");
        var username = $(this).text();
        $("#selectGiftTeacher").attr("uid", uid);
        $("#selectGiftTeacher").text(username);
        giftToTeacher = {
            uid: uid,
            nickname: username
        }
    });
    //隐藏发送礼物对象
    $(".chat-center-gift-content").on("click", function(e) {
        e.stopPropagation();
        $("#giftCountList").hide();
        $(".gift-send-teacher-list").hide()
    });
    //红包栏展开
    $(".chat-center-redpacket").click(function (){  
    	$(".sendPacketModal").show();  
    });
    //红包栏关闭
    $(".sendpacket-close").click(function (){  
    	$(".sendPacketModal").hide();  
    });
  	
    //加载emoji
    $(".chat-input-smile").on("click", function(e) {
        e.stopPropagation();
        if ($(".chat-emoji-list").css("left") == "-120px") {
            $(".chat-emoji-list").css("left", "-10000px")
        } else {
            $(".chat-emoji-list").css("left", "-120px");
            initEmoji();
            $(".chat-center-gift-content").hide()
        }
    });
    //发送文字
    $("#send").on('click',function(){
    	var content = $("#chat_content").val();
    	sendMessage(content);
    	$("#chat_content").val("");
    })
    function initEmoji() {
        var emojilist = emoji;
        var emojiArr = [];
        for (var i in emojilist) {
            var key = i,img = emojilist[i].file;
            emojiArr.push('<div class="flex chat-emoji-item" title="' + key + '" text="' + key + '" val="' + img + '">\n                                <img src="img/emoji/' + img + '">\n                                                  </div>');
        }
        $(".chat-emoji-list").html(emojiArr.join(""));
    };
    //选择emoji
    $(".chat-emoji-list").on("click", ".chat-emoji-item", function(e) {
        var text = $(this).attr("text");
        var nowmsg = $(".chat-input-text textarea").val();
        $(".chat-input-text textarea").val(nowmsg + text)
    });
  	//表白墙展开
    $(".channel-info-title").click(function (){  
    	$(".chat-room-introduce").show();
    	$(".right-hero-rank-content").hide();  
    });
    //守护周榜展开
    $(".hero-week-rank").click(function (){  
    	$(".right-hero-rank-content").show();
    	$(".chat-room-introduce").hide();    
    });
    //音量展开关闭
    $(".chat-function-text").click(function (){  
        var volume = $("div.chat-voice-volume");
        if (volume.css("display") != "none") {
              $("div.chat-voice-volume").hide()
        } else {
            $("div.chat-voice-volume").show()
        }
    });
    //关闭封禁窗口
    $("#user_mod_win_close").click(function() {
    	$(".user_mod_win").hide();
    });
    //点击 空白隐藏礼物栏、音量栏、emoji
    $(document).click(function(event){
    	var _con = $('.chat-center-gift-show');
    	var _con1 = $('.chat-center-gift-content');
    	//排除展开按钮
    	if(!_con.is(event.target) && _con.has(event.target).length === 0){
    		//排除礼物栏div子元素
    		if($(event.target).closest(_con1).length === 0){
    			$('.chat-center-gift-content').hide();
    		}
		};
		var _con2 = $('.chat-function-yinliang');
		var _con3 = $('.chat-voice-volume');
		if(!_con2.is(event.target) && _con2.has(event.target).length === 0){
    		//排除音量调节子元素
    		if($(event.target).closest(_con3).length === 0){
    			$('.chat-voice-volume').hide();
    		}
		};
		var _con4 = $('.chat-input-smile');
		var _con5 = $('.chat-emoji-list');
		if(!_con4.is(event.target) && _con4.has(event.target).length === 0){
    		//排除音emoji子元素
    		if($(event.target).closest(_con5).length === 0){
    			$(".chat-emoji-list").css("left", "-10000px");
    		}
		};
	});
	$("#user_mod_setTicket",".chat-room-item-empty", ".chat-room-item").on('click',function(){
			    	// if(authorization == 0)
			    	// 	$(".user_mod_win").hide();
			    	if($(this).attr("uid") == undefined)
			    		var id = $(this).attr("account");
			    	else
			    		var id = $(this).attr("uid");
			    	$("#user_id_cname").html(id);
			    	$(".user_mod_win").show();
    })
	//联系客服
	$(".chat-dd-kefu").click(function (){  
		if (confirm("是否在线QQ咨询？")){					
			window.open("http://wpa.qq.com/msgrd?v=3&uin=315889155&site=qq&menu=yes");
		}else{
			return;
		}
    });
	//展开登录
	$(".chat-btnlogin").click(function (){  
		$("#index_pup_box").show();  
    });
    $(".chat-room-part-name").on('click',function(){
   					lawn($(this));
   	});
 	//移入移出展示头像详情
    var kapianInterval;
    $(".chat-center-banner-main").on("mouseenter", ".main-keng-header", function() {
        var overAccount = $(this).attr("account");
        if (overAccount == 0)
            return;
        var that = this;
        kapianInterval = setTimeout(function() {
            showKapian(that, overAccount)
        }, 500)
    });
    $(".chat-center-banner-main").on("mouseleave", ".main-keng-header", function() {
	    var account = $(this).attr("account");
	    clearInterval(kapianInterval);
	    $(".chat-huiyuan-info").hide();
    });
    function showKapian(that, account) {
        var offset = $(that).offset();
        var width = $(that).css("width").replace("px", "") * 1;
        var height = $(that).css("height").replace("px", "") * 1;
        //设置头像
        $(".huiyuan-head img").attr("src",$(that).find("img").attr('src'));
        //设置ID
        $(".chat-huiyuan-info-bottom").find("a").each(function(i,n){
        	$(this).attr("uid",$(that).attr("account"));
        })
        $(".chat-huiyuan-info").css("top",offset.top + height - 15);
      	$(".chat-huiyuan-info").css("left",offset.left - width - 30);
        $(".chat-huiyuan-info").show();  
    };
    //头像详情移入移出
    $("body").on("mouseenter", ".chat-huiyuan-info", function() {
        $(this).show();
    });
    $("body").on("mouseleave", ".chat-huiyuan-info", function() {
        $(this).hide();
    });   
   	$(".chat-room-part-name").on('click',function(){
   		lawn(this);
   	});
    //登录注册切换
    $(".enroll").click(function() {
		$(".enroll").removeClass("enroll_add");
		$(this).addClass("enroll_add");
		var index = $(this).index();
		$(".enroll_content").hide();
		$(".enroll_content").eq(index).show();
	});
	//关闭登录注册面板
	$(".layer-cell-close").on("click", function(){
		$("#index_pup_box").hide();
	})
	//校验手机号
	$('#ctl00_mainContent_txt_phone').blur(function(){
		CheckPhone();
	});
	//校验用户名
	$('#user_name').blur(function(){
		$('.dislocation_box').eq(0).css('display','none');
		CheckUserName();
	})
	//校验手机号
	function CheckPhone(callback){
		var val = $('#ctl00_mainContent_txt_phone').val();
		var reg_phone = /^1\d{10}$/;
		if(!reg_phone.test(val)){
			$("#phone_tishi").text("手机号必须为11位数字");
			$("#checkall_phone").val(0);
			return;
		}
		//后台校验如果合法则执行：
		$("#phone_tishi").html('<img src="img/true.png"/>');
	};
	//校验用户名
	function CheckUserName(callback){
		var val = $("#user_name").val();
		var pattern = new RegExp("[%--`~!\#@$^&*()\\s\=|{}':;',\\[\\].<>/?~！@￥……&*（）——|{}【】‘；：”“'。，、？\"]");
		var pattern_2 = new RegExp("[0-9]+");
		if (val.length > 15 || val.length < 3) {
			$("#username_tishi").html("用户名格式不符合要求");
			return;
		}
		if (val.match(pattern) != null) {
			$("#username_tishi").html("用户名包含敏感字符");
			return;
		} else {
			if(val.match(pattern_2)==val){
				$("#username_tishi").html("用户名不能为纯数字");
				return;
			}
			//后台校验如果合法则执行：
			$("#username_tishi").html('<img src="img/true.png"/>');
		};
	};
	var lang = 0;
	//语言切换
	$("#language").click(function() {
		moveLanguage();
	});
	function moveLanguage(){
		if(lang === 0){
			$(".chat-btnlogin").html("Login");
			$(".channel-info-title").html("wall");
			$(".hero-week-rank").html("WeekList");
			$(".right_chatroom_guanming").html("Make friends～");
			$("#inputSearchKeywords").attr("placeholder","Please enter tutor nickname");
			$("#expressions").html("bold expressions of love!");
			$("#give").html("give gifts");
			$("#envelopes").html("red envelopes");
			$("#send").html("send");
			$("#mic").html("MIC");
			$("#vol").html("VOL");
			$("#kefu").html("QQ Service");
			$("#chatNewmessage").html("new messages");
			$(".chat-shangmai-btn").html("ON MIC");
			lang = 1;
			return;
		}
		if(lang === 1){
			$(".chat-btnlogin").html("登录");
			$(".channel-info-title").html("告白墙");
			$(".hero-week-rank").html("守护周榜");
			$(".right_chatroom_guanming").html("交友活动正在进行中～");
			$("#inputSearchKeywords").attr('placeholder','请输入导师昵称');
			$("#expressions").html("大胆向Ta表白吧！");
			$("#give").html("赠送礼物");
			$("#envelopes").html("发红包");
			$("#send").html("发送");
			$("#send").html("话筒");
			$("#vol").html("音量");
			$("#kefu").html("联系客服");
			$("#chatNewmessage").html("有新消息");
			$(".chat-shangmai-btn").html("上麦");
			lang = 0;
		}
	};
	//初始化useruid
	useruid = Math.round(Math.random() * 90000000 + 10000000); 
	$("#chatHeadYkNickname").html("游客" + useruid);
	//语音初始化
	clientinit();
	//加入频道
	join();
	//创建音频流
	initsteam();
	//远程音频监听
	subscribe();	
	//上麦下麦
	$(".chat-shangmai-btn").click(function() {	
		if($(".chat-shangmai-btn").html() == '上麦'){
			var temp = 0;	//是否有麦位
			var count = 0;	
			$(".main-keng-item").each(function(){
				count++;
				if($(this).is(":hidden")){
					$(this).attr("account", useruid);
					$(this).addClass("speaking");
					$(this).children(".main-xu").html(count);
					$(this).find("font").html("游客" + useruid);					
					$(this).show();
					temp = 1;
					setRole(1); //上麦
					publish();  //发布本地音频流
					return false;
				}
			 });
			 if(temp == 0){
			 	alert("当前无麦位");
			 	return;
			 }
			$(".chat-shangmai-btn").html('下麦');
			return;
		}
		if($(".chat-shangmai-btn").html() == '下麦'){
			$(".main-keng-item").each(function(){
				if($(this).attr("account") == useruid){
					$(this).hide();
					setRole(0);	//下麦
					return false;	
				}
			 });
			$(".chat-shangmai-btn").html('上麦');
			return;
		}
	});	
	
	
});
//房间列表下拉监听
   	function lawn(that){
   		if($(that).attr("alt") == "hide"){
   			$(that).parent().find('div').show();
   			$(that).attr("alt","show");
   		}
   		else{
   			$(that).parent().find('div').hide();
   			$(that).attr("alt","hide");
   		}
   	}
//用户id
var useruid;

//语音测试
var APPID = "10f9f1d5730a42c891e57ba1c20b45fd";
var TOKEN_OR_KEY = "006aecdd1fcde204bd4a4b0ec6cb4777fc4IACk9T802tJsZS4o8rIhAxauUG+TRbZPyYcm9mLhp4sAjQx+f9gAAAAAEABkYBGvPrZPXQEAAQA8tk9d";
var CHANNEL_NAME = "test";
var UID = useruid;
var myuid;
var client;
var localStream;	
function clientinit(){
	//创建客户端
	RTC = AgoraRTC.createClient({mode: 'live', codec: "h264"});
	//客户端初始化
	RTC.init(APPID, function () {
	  console.log("AgoraRTC client initialized");
	  getToken(useruid,CHANNEL_NAME);
	}, function (err) {
	  console.log("AgoraRTC client init failed", err);
	});
}
function join(){
	//加入频道
	RTC.join(TOKEN_OR_KEY, CHANNEL_NAME, useruid, function(uid) {
		myuid = uid;
		console.log("User " + uid + " join channel successfully");
	//加载频道
	}, function(err) {
	  console.log("Join channel failed", err);
	});
}
function initsteam(){
	//创建音频流对象
	localStream = AgoraRTC.createStream({
	    streamID: myuid,	//音视频流 ID。设置为用户 ID （uid），可通过 client.join 的回调获取
	    audio: true,	//是否开启音频。
	    video: false,	//是否开启视频。
	    screen: false}	// 是否开启屏幕共享功能。请勿将 video 和 screen 同时设置为 true 。
	);
	//初始化音频流
	localStream.init(function() {
	  console.log("getUserMedia successfully");
	  // 这里使用agora_local作为dom元素的id。
	  localStream.play('agora_local');
	
	}, function (err) {
	  console.log("getUserMedia failed", err);
	});
}

function publish(){
	//发布本地音频流
	RTC.publish(localStream, function (err) {
	  console.log("Publish local stream error: " + err);
	});
	//监听发布流成功事件
	RTC.on('stream-published', function (evt) {
	  console.log("Publish local stream successfully");
	});

}

function subscribe(){
	//订阅远端音频流
	//1.监听 client.on('stream-added') 事件, 当有人发布音频流到频道里时，会收到该事件
	RTC.on('stream-added', function (evt) {
	  var stream = evt.stream;
	  console.log("New stream added: " + stream.getId());
	  
	  //2.收到事件后，在回调中调用 client.subscribe 方法订阅远端音频流
	  RTC.subscribe(stream, function (err) {
	    console.log("Subscribe stream failed", err);
	  });
	});
	
	/*
	 在初始化流成功和订阅流成功后，都可以在回调中调用 stream.play 在页面上播放流。
	stream.play 接受一个 dom 元素的 id 作为参数，SDK 会在这个 dom 下面创建一个 <video> 标签
	并播放音频。
	*/
	//订阅监听，订阅流成功时，播放远端流
	RTC.on('stream-subscribed', function (evt) {
	  var remoteStream = evt.stream;
	  console.log("Subscribe remote stream successfully: " + remoteStream.getId());
	  remoteStream.play('agora_remote' + remoteStream.getId());
	});
};
function myleave(){
	//使用 client.leave 方法让用户离开当前通话或直播（频道）
	RTC.leave(function () {
	  console.log("Leave channel successfully");
	}, function (err) {
	  console.log("Leave channel failed");
	});
}
//设置用户权限host主播，audience观众
function setRole(flag){
	var role;
	if(flag == 1){
		role = "host";
	}else{
		role = "audience";
	}
	RTC.setClientRole(role, function() {
	  console.log("setHost success");
	}, function(e) {
	  console.log("setHost failed", e);
	})
};
//RTM初始化
function initRTM(APPID)
{
	rtm = AgoraRTM.createInstance(APPID);
	rtm.on("ConnectionStateChanged", (newState, reason) => {
    console.log("reason", reason);
    const view = $("<div/>",{
      text: ["newState: " + newState, ", reason: ", reason].join(""),
    })
    $("#log").append(view)
  })

  rtm.on("MessageFromPeer", (message, peerId) => {
    console.log("message "+ message.text + " peerId" + peerId);
    const view = $("<div/>",{
      text: ["message.text: " + message.text, ", peer: ", peerId].join(""),
    })
    $("#log").append(view)
  });

  rtm.on("MemberJoined", ({channelName, args}) => {
    const memberId = args[0];
    console.log("channel ", channelName, " member: ", memberId, " joined");
    const view = $("<div/>",{
      text: ["event: MemberJoined ", ", channel: ", channelName, ", memberId: ", memberId].join(""),
    })
    $("#log").append(view);
  });

  rtm.on("MemberLeft", ({channelName, args}) => {
    const memberId = args[0];
    console.log("channel ", channelName, " member: ", memberId, " joined");
    const view = $("<div/>",{
      text: ["event: MemberLeft ", ", channel: ", channelName, ", memberId: ", memberId].join(""),
    })
    $("#log").append(view);
  });
	rtm.on('ConnectionStateChanged', (newState, reason) => {
  		if(reason == "LOGIN_SUCCESS"){
  			console.log("uid:" +useruid+ " 登录成功");
  		}
  	});
}
//登录
function login(impid){
	rtm.login({uid:impid.toString()}).then(() => {
  		console.log('AgoraRTM client login success');
	}).catch(err => {
  		console.log('AgoraRTM client login failure', err);
	})
};
//退出登录
function logout(){
	rtm.logout();
}
//创建频道
function createChannel(){
	channel = rtm.createChannel("test"); // 此处传入频道 ID
	setListener();
}
//加入频道
function joinChannel(){
	channel.join().then(() => {
		$(".chatroom-gonggao").append("<div class='flex getredbag-message' style='margin:10px 0;'><div class='flex welcome-get-message' id='log'>欢迎 <span>"+useruid+"</span> 进入频道</div></div>");
		console.log("进入频道成功！");
  /* 加入频道成功的处理逻辑 */
}).catch(error => {
  /* 加入频道失败的处理逻辑 */
  		console.log("进入频道失败",error);
})};	
//发送频道消息
function sendMessage(message){
	channel.sendMessage({ text: message }).then(() => {
		$(".chatroom-gonggao").append("<div class='flex getredbag-message' style='margin:10px 0;'><div class='flex welcome-get-message' id='log'><span>"+useruid+":</span>" +message+ "</div></div>");
		console.log("发送文本：" + message);
  /* 频道消息发送成功的处理逻辑 */
	}).catch(error => {
		console.log(error);
  /* 频道消息发送失败的处理逻辑 */
})};
//接收频道消息
function relayMessage(){
	channel.on('ChannelMessage', ({ text }, senderId) => { // text 为收到的频道消息文本，senderId 为发送方的 User ID
		$(".chatroom-gonggao").append("<div class='flex getredbag-message' style='margin:10px 0;'><div class='flex welcome-get-message' id='log'><span>"+senderId+":</span>" +text+ "</div></div>");
  /* 收到频道消息的处理逻辑 */
})};
//监听
function setListener(){
	channel.on('MemberJoined', memberId => { // memberId 为加入频道的用户 ID
  /* 收到频道用户加入通知的处理逻辑 */
  		$(".chatroom-gonggao").append("<div class='flex getredbag-message' style='margin:10px 0;'><div class='flex welcome-get-message' id='log'>欢迎 <span>"+memberId+"</span> 进入频道</div></div>");
  	});
  	channel.on('MemberLeft', memberId => { // memberId 为离开频道的用户 ID
  /* 收到频道用户离开通知的处理逻辑 */
  		console.log("离开" + memberId);
	});
}
//退出频道
function quitChannel(){
	channel.leave();
}
//获取token
function getToken(id,_cname){
	$.ajax({
		url:"https://www.suprass.cn/portal/chat/user",
		dataType:"json",
		data:{"uid":id,"cname":_cname},
		success:function(e){
			e = eval(e.data);
			//TOKEN_OR_KEY = e.token;
			console.log("uid:" + id + " Token:" + e.token);
			initRTM(APPID);
			login(id);//登录
			createChannel();//创建频道 
			getRoomList();//获取列表
			setTimeout('joinChannel()',3000);//创建频道并进入
		}
	})
}